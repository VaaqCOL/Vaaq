### IN DEVELOPMENT

### Hola👋

Hola, soy Bruno. Actualmente estoy estudiando en una secundaria dedicada solo a la Informatica.

- 👀 Estoy interesado en formar partes de proyectos.
- 🌱 Estoy aprendiendo JS, Python, C++ y mas cosas a futuro.
- 💞️ Estoy buscando colaborar en cosas relacionadas con Discord.
- 📫 Para hablarme solo mandame un md a noxx#6511

### 📈 Github Stats

<!-- Contribution graph -->
<p justify-content="center">
 <img width="100%" src="https://activity-graph.herokuapp.com/graph?username=elnoxx16&theme=react-dark&custom_title=Contribution%20Graph">
</p>
<!-- stats profile -->
<div align="justify">
<img width="49%" src=https://github-readme-stats.vercel.app/api?username=elnoxx16&show_icons=true&theme=dark&custom_title=noxx%20's%20Github%20Profile>
<!-- Top languages -->
<img width="49%" src=https://github-readme-stats.vercel.app/api/top-langs/?username=elnoxx16&layout=compact&hide=roff,MATLAB&langs_count=8&theme=dark&custom_title=Top%20languages>
</div>

## 🛸 Discord Status

 <img src="https://discord.c99.nl/widget/theme-4/907330150369222717.png" />
